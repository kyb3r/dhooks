from setuptools import setup
setup(
    name="discord_hooks",
    version='1.0',
    scripts=['discord_hooks.py']
)